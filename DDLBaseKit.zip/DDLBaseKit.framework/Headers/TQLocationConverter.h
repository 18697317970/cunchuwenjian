//
//  TQLocationConverter.h
//  
//
//  Created by qfu on 9/16/14.
//  Copyright (c) 2014 tinyq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>


/**
 地球坐标(WGS84):google、高德国外
 国际标准，GPS标准从GPS设备中取出的原始数据是就是这个
 国际地图提供商一般使用的也是这个
 
 火星坐标(GCJ-02):google国内、高德国内
 
 中国标准，行货GPS设备取出的最终数据是这个
 国家龟腚：国内出版的各种地图系统（包括电子形式），必须至少采用GCJ-02对地理位置进行首次加密。
 
 百度坐标(BD-09):百度
 百度标准，百度SDK，地图，Geocoding用的都是这个。
 */


@interface TQLocationConverter : NSObject

/**
 *  判断是否在中国
 */
+(BOOL)isLocationOutOfChina:(CLLocationCoordinate2D)location;

/**
 *  将WGS-84转为GCJ-02(火星坐标):
 */
+(CLLocationCoordinate2D)transformFromWGSToGCJ:(CLLocationCoordinate2D)wgsLoc;

/**
 *  将GCJ-02(火星坐标)转为百度坐标:
 */
+(CLLocationCoordinate2D)transformFromGCJToBaidu:(CLLocationCoordinate2D)p;

/**
 *  将百度坐标转为GCJ-02(火星坐标):
 */
+(CLLocationCoordinate2D)transformFromBaiduToGCJ:(CLLocationCoordinate2D)p;

/**
 *  将GCJ-02(火星坐标)转为WGS-84:
 */
+(CLLocationCoordinate2D)transformFromGCJToWGS:(CLLocationCoordinate2D)p;

@end
