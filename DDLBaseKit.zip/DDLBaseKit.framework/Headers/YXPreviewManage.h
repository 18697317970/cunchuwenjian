//
//  YXPreviewManage.h
//  BusinessFine
//
//  Created by 杨旭 on 2019/10/21.
//  Copyright © 2019年 杨旭. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>
#import <SDImageCache.h>

NS_ASSUME_NONNULL_BEGIN
/// 获取 原图 的闭包
typedef NSString * _Nullable (^DDOriginalBlock)(void);

@interface DDPreViewImageModel : NSObject

/// 本地图片名字
@property (nonatomic, copy, nullable) NSString *imageName;
/// 本地图片路径
@property (nonatomic, copy, nullable) NSString *imagePath;
/// 本地图片字节码
@property (nonatomic, copy, nullable) NSData *imageData;
/// 本地图片
@property (nonatomic, copy, nullable) UIImage *image;
/// 网络图片资源
@property (nonatomic, copy, nullable) NSString *imageURL;
/// 相册图片资源
@property (nonatomic, strong, nullable) PHAsset *imagePHAsset;

/// 投影视图，当前数据模型对应外界业务的 UIView (通常为 UIImageView)，做转场动效用
@property (nonatomic, weak, nullable) __kindof UIView *projectiveView;
/// 预览图/缩约图，注意若这个图片过大会导致内存压力（若 projectiveView 存在且是 UIImageView 类型将会自动获取缩约图）
@property (nonatomic, strong, nullable) UIImage *thumbImage;
/// 预览图/缩约图 URL，缓存中未找到则忽略（若 projectiveView 存在且是 UIImageView 类型将会自动获取缩约图）
@property (nonatomic, copy, nullable) NSURL *thumbURL;
@property (nonatomic, copy, nullable) DDOriginalBlock originalPath;

@end;

@interface DDPreViewVideoModel : NSObject

/// 视频 URL
@property (nonatomic, copy, nullable) NSURL *videoURL;
/// 相册视频资源
@property (nonatomic, strong, nullable) PHAsset *videoPHAsset;

/// 视频 AVAsset (通常使用 AVURLAsset)
@property (nonatomic, strong, nullable) AVAsset *videoAVAsset;

/// 投影视图，当前数据模型对应外界业务的 UIView (通常为 UIImageView)，做转场动效用
@property (nonatomic, weak, nullable) __kindof UIView *projectiveView;

/// 预览图/缩约图，若 projectiveView 存在且是 UIImageView 类型将会自动获取缩约图
@property (nonatomic, strong, nullable) UIImage *thumbImage;

@end;


@interface YXPreviewManage : NSObject

@property (nonatomic ,copy) void(^loadMore)(void);///<加载更多


+ (YXPreviewManage *)sharePreviewManage;
// 预览图片
- (void)showPhotoWithImgArr:(NSArray *)imgArr currentIndex:(NSInteger)currentInde;

- (void)reload:(NSArray *)imgArr;

@end

NS_ASSUME_NONNULL_END
