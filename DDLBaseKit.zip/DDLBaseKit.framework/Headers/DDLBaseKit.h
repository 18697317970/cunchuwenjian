//
//  DDLBaseKit.h
//  Pods
//
//  Created by wanggang on 2020/4/16.
//

#ifndef DDLBaseKit_h
#define DDLBaseKit_h
#pragma mark ----- 引用库
#import "AFNetworking.h"
#import "MJRefresh.h"
#import "SDWebImage/UIImageView+WebCache.h"
#import "SDWebImage/UIButton+WebCache.h"
#import "DateTools.h"
#import "MJExtension.h"
#import "RTRootNavigationController.h"
#import "Masonry.h"
#import "UIScrollView+EmptyDataSet.h"
#import "DDScanViewController.h"

#pragma mark ----- 引用基类
#import "DDBaseTableViewCell.h"
#import "DDBaseViewController.h"
#import "DDBaseNavigationController.h"
#import "DDBaseModel.h"


#pragma mark ----- 引用通用类
#import "NetWork.h"
#import "UISet.h"
#import "UserData.h"
#import "UIViewController+DDCommonFunc.h"
#import "UIColor+DDAdditional.h"
#import "UIView+DDAdditional.h"
#import "NSBundle+DDLBaseKit.h"

#import "UIButton+Extensions.h"
#import "UILabel+AttributedText.h"
#import "NSString+DDRegularExpression.h"
#import "NSString+DDAdditional.h"
#import "NSMutableAttributedString+Additional.h"
#import "YXCustomAlertActionView.h"
#import "TotastView.h"
#import "YJProgressHUD.h"


#pragma mark ----- 引用工具类
#import "ToolBox.h"
#import "UIViewController+KNSemiModal.h"
#import "DDLBaseKitManager.h"
#import "DDInterfaceManager.h"


#pragma mark ----- 引用宏定义
#import "Color.h"
#import "Config.h"
#import "ResponseCode.h"
#import "Interface.h"
#import "TipMsg.h"
#import "TextFont.h"

#endif /* DDLBaseKit_h */
