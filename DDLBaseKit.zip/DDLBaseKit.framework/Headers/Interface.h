//
//  Interface.h
//  DDLife
//
//  Created by 赵越 on 2019/7/11.
//  Copyright © 2019 赵越. All rights reserved.
//


#ifndef Interface_h
#define Interface_h


///是否显示广告
#define SHOWADVERTISEMENT YES

//------ 网络请求接口 ------
#ifdef DEBUG //处于开发阶段
#define DevepMent 0  //1为开发接口， 2为正式接口
#else //处于开发阶段
#define DevepMent 0  //0为正式接口，永远不要改
#endif

#define IOT_USER_COS_URL    [NSString stringWithFormat:@"%@",DD_IOT_USER_COS_URL]// COS用户中心
#define IOT_USER_URL        [NSString stringWithFormat:@"%@",DD_IOT_USER_URL]// 用户中心
#define IOT_BASE_URL        [NSString stringWithFormat:@"%@",DD_IOT_BASE_URL]// 邀请访客
#define SMART_BASE_PATH     [NSString stringWithFormat:@"%@",DD_SMART_BASE_PATH]//智能硬件
#define SMART_RECHARGE_PATH [NSString stringWithFormat:@"%@",DD_SMART_RECHARGE_PATH]// 云充电地址
#define IOT_DOOR_URL        [NSString stringWithFormat:@"%@",DD_IOT_DOOR_URL]// 云门禁地址
#define IOT_SUPERDOOR_URL   [NSString stringWithFormat:@"%@",DD_IOT_SUPERDOOR_URL]// 超级屏云门禁地址
#define IOT_INTERCOM_URL    [NSString stringWithFormat:@"%@",DD_IOT_INTERCOM_URL]// 云对讲地址
#define IOT_PARKING_URL     [NSString stringWithFormat:@"%@",DD_IOT_PARKING_URL]// 停车地址
#define IOT_VIDEO_URL       [NSString stringWithFormat:@"%@",DD_IOT_VIDEO_URL]// 监控地址
#define IOT_PAY_URL         [NSString stringWithFormat:@"%@",DD_IOT_PAY_URL]// 支付地址
#define IOT_SHOP_URL        [NSString stringWithFormat:@"%@",DD_IOT_SHOP_URL]// 商城地址
#define IOT_FACE_RECOG      [NSString stringWithFormat:@"%@",DD_IOT_FACE_RECOG]// 人脸识别--以/结尾 （ps:同用户中心一个模块(IOT_USER_URL -- 只是最后差个/)）- 测试-zlj
#define SMART_METERPLAT_PATH DD_SMART_METERPLAT_PATH //智能水电表

#define ASSET_BASE_PATH         [IOT_SHOP_URL stringByAppendingString:@"asset/"]
#define MAEKETING_BASE_PATH     [IOT_SHOP_URL stringByAppendingString:@"marketing/"]
#define SHOP_BASE_PATH          [IOT_SHOP_URL stringByAppendingString:@"shop/"]
#define REGULA_BASE_PATH        [IOT_SHOP_URL stringByAppendingString:@"regula/"]
#define ORDER_BASE_PATH         [IOT_SHOP_URL stringByAppendingString:@"order/"]
#define EVALUATE_BASE_PATH      [IOT_SHOP_URL stringByAppendingString:@"evaluate/"]
#define OPERATOR_BASE_PATH      [IOT_SHOP_URL stringByAppendingString:@"operator/"]

#define baseurl @"http://shop.ddsaas.com/"
#define kUserBasePath [NSString stringWithFormat:@"%@user/",baseurl]


//尽量做到接口与更新版本相关联
#pragma mark -------- Version 1.0.0
#pragma mark - 登录
#define DD_LOGIN_LOGIN  [IOT_USER_COS_URL stringByAppendingString:@"auth/movelogin"]

#pragma mark - 注册
#define DD_REGISTER_REGISTER  [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/register.do"]

#pragma mark - 忘记密码
#define DD_REGISTER_FORGET  [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/updatapassword.do"]

#pragma mark - 获取注册短信验证码
#define DD_REGISTER_SMSCODE  [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/yzm.do"]

#pragma mark - 获取忘记密码短信验证码
#define DD_FORGET_SMSCODE   [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/lostSMS.do"]

#pragma mark - 验证邀请码
#define DD_REGISTER_RECOMMENDCODE   [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/recommend/checkRecommendCode.do"]

#pragma mark - 保存业主的直接推荐人和间接推荐人信息
#define DD_REGISTER_SAVERECOMMENDCODE   [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/recommend/saveRecommendRecord.do"]

#pragma mark - 获取用户服务地址
#define DD_LOGIN_QUERYADDRESS    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/queryAddressByUserId.do"]

#pragma mark - 获取用户信息
#define DD_LOGIN_QUERYUSERINFO  [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/queryUserInfo.do"]

#pragma mark - 退出登录
#define DD_LOGIN_OUT    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/logOut.do"]
#pragma mark - IM登录
#define DD_LOGIN_IM    [IOT_USER_COS_URL stringByAppendingString:@"auth/im/queryUserImAccount"]
#pragma mark - IM查询用户聊天关系
#define DD_LOGIN_IM_UserRelation    [IOT_USER_COS_URL stringByAppendingString:@"auth/im/queryUserRelation"]
#pragma mark - IM查询用户聊天关系
#define DD_LOGIN_IM_Querykeywordsendmsgn    [IOT_USER_COS_URL stringByAppendingString:@"auth/im/querykeywordsendmsg"]

#pragma mark - 上传用户头像
#define DD_USER_UOLOADAVATAR    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/uploadPerionPhoto.do"]

#pragma mark - 修改用户信息 2性别、1姓名、3收货地址
#define DD_USER_CHANGEINFO      [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/updatePersonInfo.do"]
#pragma mark - 修改推送token
#define DD_USER_APNSToken      [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/iosUpdateUmToken.dd"]
#pragma mark - 检测是否新用户
#define DD_USER_checkIsNewUser      [IOT_USER_COS_URL stringByAppendingString:@"/auth/1_0/userPlat/app/smallProgram/checkIsNewUser"]
#pragma mark - 修改信息
#define DD_USER_updateIsNewUser      [IOT_USER_COS_URL stringByAppendingString:@"/auth/1_0/userPlat/app/smallProgram/updateIsNewUser"]
#pragma mark - 查查用户信息是否存在
#define DD_USER_checkUserMassage      [IOT_USER_COS_URL stringByAppendingString:@"/auth/appuser/massage/checkUserMassage"]

#pragma mark - 修改用户出生日期
#define DD_USER_CHANGEBIRTHDATE   [IOT_USER_URL stringByAppendingString:@"/app/person/updateBirthdate.dd"]

#pragma mark - 查询兴趣标签
#define DD_USER_QUERYHOBBYLIST  [IOT_USER_URL stringByAppendingString:@"/user/hobby/queryHobbyList.dd"]

#pragma mark - 添加自定义标签
#define DD_USER_ADDHOBBY     [IOT_USER_URL stringByAppendingString:@"/user/hobby/addHobby.dd"]

#pragma mark - 删除自定义标签
#define DD_USER_DELETEHOBBY    [IOT_USER_URL stringByAppendingString:@"/user/hobby/deleteHobby.dd"]

#pragma mark - 用户点击完成保存的选中的标签
#define DD_USER_ADDUSERHOBBY    [IOT_USER_URL stringByAppendingString:@"/user/hobby/addUserhobby.dd"]

#pragma mark - 修改支付密码
#define DD_USER_PAYPSD      [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/payPwd/updataPayPassword.do"]

#pragma mark - 修改登录密码 //DD_REGISTER_FORGET
#define DD_USER_LOGINPSD     [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/updatapassword.do"]

#pragma mark - 获取余额
#define DD_MINE_BALANCE     [IOT_PAY_URL stringByAppendingString:@"/app/balance/queryAppBalance.do"]

#pragma mark - 获取消费记录
#define DD_MINE_BALANCERECORD     [IOT_PAY_URL stringByAppendingString:@"/app/balance/interface/queryUserBalanceRecord.do"]

#pragma mark - IOT各平台单独发起支付和app发起支付查询支付参数
#define DD_MINE_PLATACCOUNT     [IOT_PAY_URL stringByAppendingString:@"/payplat/queryOtherPlatAccount.do"]

#pragma mark - 统一下单接口
#define DD_MINE_PAYORDER     [IOT_PAY_URL stringByAppendingString:@"/pay/unifiedorder.do"]

#pragma mark - app查询本人人脸库信息
#define DD_MINE_APPFACE     [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/queryAppFaceInfoNew.dd"]

#pragma mark - app查询已经存在的家庭成员信息
#define DD_MINE_OTHERFACE     [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/queryAppOtherFaceInfoNew.dd"]

#pragma mark - app新增人脸信息
#define DD_MINE_SAVEFACE     [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/saveFaceByAppNew.dd"]

#pragma mark - app重新上传人脸照片
#define DD_MINE_UPDATEFACE     [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/updateFacePhoto.dd"]

#pragma mark - 删除
#define DD_MINE_DELETEFACE     [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/deleteFaceByApp.dd"]

#pragma mark - app修改房间权限
#define DD_MINE_UPDATEPOWER    [IOT_FACE_RECOG stringByAppendingString:@"userPlat/face/app/updatePowerByApp.dd"]

#pragma mark - 判断是否有支付密码
#define DD_MINE_ISPAYPSD    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/payPwd/isPayPassword.do"]

#pragma mark - 验证支付密码
#define DD_MINE_COMPAREPAYPSD    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/payPwd/comparePayPassword.do"]

#pragma mark - 请求安全级别的签名
#define DD_MINE_TOKENSIGN    [IOT_USER_URL stringByAppendingString:@"/1_0/userPlat/app/smallProgram/tokenSwitchSign.do"]

#pragma mark - 提现
#define DD_MINE_TOCASH      [IOT_PAY_URL stringByAppendingString:@"/app/balance/cashWithdrawal.do"]

#pragma mark - 显示推荐返现
#define DD_MINE_FANXIAN      [ASSET_BASE_PATH stringByAppendingString:@"/recommendCashBack/interface/showRewards3.dd"]

#pragma mark - 奖励明细
#define DD_MINE_RewardDetails      [ASSET_BASE_PATH stringByAppendingString:@"/app/Recommend/cashBack/queryRewardDetails.dd"]

#pragma mark - 用户设置
#define DD_MINE_QUERYUSERSETTING      [IOT_USER_COS_URL stringByAppendingString:@"/auth/user/setting/queryUserSetting"]

#pragma mark - 修改用户设置
#define DD_MINE_UPDATEUSERSETTING      [IOT_USER_COS_URL stringByAppendingString:@"/auth/user/setting/updateUserSetting"]


#pragma mark - 开店零门槛
#define DD_MINE_StoreWebUrl  @"https://cos.dd2007.com/setshop.html"

#pragma mark - 免费投广告
#define DD_MINE_AdvertWebUrl  @"https://cos.dd2007.com/freeAdvertising.html"

#pragma mark - 在线帮助
#define DD_MINE_HelpWebUrl  @"https://cos.dd2007.com/staticPage/onlineHelp.html"

#pragma mark - 认证房间
#define DD_MINE_RoomWebUrl  @"https://cos.dd2007.com/staticPage/attestationRoom.html"

#pragma mark - 采集人脸
#define DD_MINE_FaceWebUrl  @"https://cos.dd2007.com/staticPage/acquisitionFaces.html"

#pragma mark - 缴物业费
#define DD_MINE_PayCostWebUrl  @"https://cos.dd2007.com/staticPage/toPayPropertyCosts.html"

#endif /* Interface_h */
