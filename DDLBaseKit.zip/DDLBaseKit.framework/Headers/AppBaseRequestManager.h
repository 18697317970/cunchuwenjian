//
//  AppBaseRequestManager.h
//  ZanXiaoQu
//
//  Created by TomLong on 2018/12/5.
//  Copyright © 2018年 DianDu. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^ApiRequestCallBack)(id responesObj,NSError *error);

@interface AppBaseRequestManager : NSObject

/**
 GET请求 By NSURLSession

 @param urlString URL
 @param parameters 参数
 */
+ (void)GET:(NSString *)urlString parameters:(id)parameters complectionHandler:(void(^)(id responseObj,NSError *error))complectionHandler;

/**
 POST请求 By NSURLSession
 
 @param urlString URL
 @param parameters 参数
 */
+ (void)POST:(NSString *)urlString parameters:(id)parameters complectionHandler:(void(^)(id responseObj,NSError *error))complectionHandler;




/**
 sign GET请求
 
 @param urlString URL
 @param parameters 参数
 */

+ (void)GET:(NSString *)urlString Sign:(NSString *)sign parameters:(id)parameters complectionHandler:(void(^)(id responseObj,NSError *error))complectionHandler;


/**
 sign POST请求

 @param urlString URL
 @param sign      签名验证
 @param parameters 参数
 */
+ (void)POST:(NSString *)urlString Sign:(NSString *)sign parameters:(id)parameters complectionHandler:(void(^)(id responseObj,NSError *error))complectionHandler;

/**
 上传图片

 @param urlString URL
 @param parameters 参数
 @param fileParameters 图片参数
 @param complectionHandler 回调
 */
+ (void)PostImage:(NSString *)urlString parameters:(id)parameters fileParameters:(NSArray <UIImage *>*)fileParameters complectionHandler:(void(^)(id responesObj,NSError *error))complectionHandler;
/**
 取消网络请求
 */
+ (void)cancelAllNetWorkingTool;

/**
 网络转态
 */
+ (void)netWorkingStateType;


/**
 显示无网络提示

 @param message 提示信息
 */
+ (void)showNoNetwrokingMessage:(NSString *)message;

/**
 401 -- 退出登录

 @param code    401提示
 @param alert   提示信息
 */
+(void)clearLogIn:(NSInteger)code and:(NSString*)alert;
@end

NS_ASSUME_NONNULL_END
