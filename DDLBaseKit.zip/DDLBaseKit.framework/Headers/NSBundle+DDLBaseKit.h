//
//  NSBundle+DDLBaseKit.h
//  AFNetworking
//
//  Created by wanggang on 2020/4/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (DDLBaseKit)

+ (NSBundle *)DD_MyLibraryBundle:(NSString *)libraty;
    
+ (UIImage *)DD_imageNamed:(NSString *)name;

    
+ (UIImage *)DD_imageNamed:(NSString *)name bundle:(NSString *)bundle;

@end

NS_ASSUME_NONNULL_END
