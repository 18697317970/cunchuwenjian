//
//  WGAdWebViewController.h
//  DDLife
//
//  Created by wanggang on 2019/12/17.
//  Copyright © 2019年 点都. All rights reserved.
//

#import "DDBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface WGAdWebViewController : DDBaseViewController

@property (strong, nonatomic)  NSString *titleStr;

@property (strong, nonatomic)  NSString *adUrl;


@end

NS_ASSUME_NONNULL_END
