//
//  UserData.h
//  DDLife
//
//  Created by 赵越 on 2019/7/11.
//  Copyright © 2019 赵越. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface IsNewUser : NSObject

@property (nonatomic , assign) NSInteger         isnewlogin;//2 已填写
@property (nonatomic , assign) BOOL              state;//true:表示用户是新用户，没有消费过， false 表示用户不是新用户，已经消费过
@end

@interface CheckUserRedHot : NSObject

@property (nonatomic , assign) NSInteger         faceType;//1有红点  2没  3未知状态

@end

/**
 用于存储登录用户的数据
 */

@interface HomeInfoModel :NSObject

@property (nonatomic , copy) NSString              * houseId;//类型：String  必有字段  备注：项目id
@property (nonatomic , copy) NSString              * biaoshi;//类型：String  必有字段  备注：固定的 - 2018
@property (nonatomic , copy) NSString              * contractNo;//类型：String  必有字段  备注：合同编号
//类型：String  必有字段  备注：业主(owner),业主成员(ownerMember),租户(tenant),租户成员(tenantMember)
@property (nonatomic , copy) NSString              * sign;
@property (nonatomic , copy) NSString              * wycompanyName;//物业公司名字
@property (nonatomic , copy) NSString              * remark;//备注 -- 无用到
@property (nonatomic , assign) NSInteger           auditState;//房间信息审核 状态 1/0
@property (nonatomic , copy) NSString              * houseName;//项目名称
@property (nonatomic , copy) NSString              * customerSign;
@property (nonatomic , copy) NSString              * unintId;//单元id
@property (nonatomic , copy) NSString              * customerId;//物业系统的保存的id -- 关联id
@property (nonatomic , copy) NSString              * wycompanyId;//物业公司id
@property (nonatomic , copy) NSString              * kId;//业主住户信息的主键id
@property (nonatomic , copy) NSString              * propertyId;//房间id
@property (nonatomic , copy) NSString              * channelId;
@property (nonatomic , copy) NSString              * machineCode;
@property (nonatomic , copy) NSString              * unitName;//单元名字
@property (nonatomic , copy) NSString              * mobile;//手机号码
@property (nonatomic , assign) NSInteger           active;//状态 1/ -1
@property (nonatomic , copy) NSString              * buildingId;//楼栋id
@property (nonatomic , copy) NSString              * wyhouseId;//物业系统项目id  -- 和宏定义冲突需要修改为kWyhouseId
@property (nonatomic , copy) NSString              * buildingName;//楼栋名字
@property (nonatomic , copy) NSString              * wycompanyUrl;//物业的URL
@property (nonatomic , copy) NSString              * hardRoomNo;//硬件房号
@property (nonatomic , copy) NSString              * propertyName;//房间名字
@property (nonatomic , copy) NSString              * branchCompanyId;//分公司id
@property (nonatomic , copy) NSString              * name;//名字 -- 用户名
@property (nonatomic , copy) NSString              * changeState;//业主或租户或成员状态 0：当前用户；1：历史用户
@property (nonatomic , copy) NSString              * channelName;//渠道名称
@property (nonatomic , copy) NSString              * memberType;
@property (nonatomic , copy) NSString              * branchCompanyName;//分公司名称

@property (nonatomic , copy) NSString              * HomeAddress;//房间地址全称


@end


@interface UserData : NSObject <NSCoding>
#pragma mark - 登录接口返回
//token
@property (nonatomic ,copy) NSString *mobileToken;
// userId;
@property (nonatomic ,copy) NSString *userId;
// 手机号码
@property (nonatomic ,copy) NSString *mobile;
//用户头像
@property (nonatomic ,copy) NSString *headImgUrl;
// 用户名
@property (nonatomic ,copy) NSString *userName;
// 用户真实姓名
@property (nonatomic ,copy) NSString *userRealName;
// uid
@property (nonatomic ,copy) NSString *uid;
// 性别
@property (nonatomic ,assign) NSInteger sex;
// 支付密码
@property (nonatomic ,copy) NSString *payPassword;



#pragma mark - 用户信息接口返回
@property (nonatomic, copy) NSString        *account;
@property (nonatomic, copy) NSString        *createPerson;
@property (nonatomic, assign) NSInteger     active;
@property (nonatomic, copy) NSString        *appType;
@property (nonatomic, copy) NSString        *openId;
@property (nonatomic, copy) NSString        *updatePerson;
@property (nonatomic, copy) NSString        *updateTime;
// 收货地址
@property (nonatomic, copy) NSString        *shopAddress;
@property (nonatomic, copy) NSString        *vendor;
// 设备token
@property (nonatomic, copy) NSString        *deviceToken;
@property (nonatomic, copy) NSString        *systemType;
@property (nonatomic, copy) NSString        *name;
// 用户出生日期
@property (nonatomic, copy) NSString        *birthdate;

@property (nonatomic, copy) NSString        *createTime;
@property (nonatomic, copy) NSString        *model;
@property (nonatomic, copy) NSString        *umToken;
@property (nonatomic, copy) NSString        *remark;
// 房间信息
@property (nonatomic , copy) NSArray<HomeInfoModel *>              * homeInfo;
@property (nonatomic , strong) HomeInfoModel              * selectHomeInfo;


#pragma mark - 根据用户情况设置或标注
// 用户身份
@property (nonatomic ,copy) NSString *identity;
// 首页选中的房屋行数 (houseRow)
//@property (nonatomic, copy) NSString *selectHouseId;
// 运营商id
@property (nonatomic, copy) NSString *operatorID;



// 获取对象
+ (UserData *)currentUser;
// 赋值
- (void)giveData:(NSDictionary *)dic;
// 删除
- (void)removeMe;
- (void)saveMe;
// 修改房间信息
- (void)modifyWithDic:(NSDictionary *)dic;
@end

NS_ASSUME_NONNULL_END
