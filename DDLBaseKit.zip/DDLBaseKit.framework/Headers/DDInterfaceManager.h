//
//  DDInterfaceManager.h
//  AFNetworking
//
//  Created by wanggang on 2020/4/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * DD_IOT_USER_COS_URL;
extern NSString * DD_IOT_USER_URL;
extern NSString * DD_IOT_BASE_URL;
extern NSString * DD_SMART_BASE_PATH;
extern NSString * DD_SMART_RECHARGE_PATH;
extern NSString * DD_IOT_DOOR_URL;
extern NSString * DD_IOT_SUPERDOOR_URL;
extern NSString * DD_IOT_INTERCOM_URL;
extern NSString * DD_IOT_PARKING_URL;
extern NSString * DD_IOT_VIDEO_URL;
extern NSString * DD_IOT_PAY_URL;
extern NSString * DD_IOT_SHOP_URL;
extern NSString * DD_IOT_FACE_RECOG;
extern NSString * DD_SMART_METERPLAT_PATH;



@interface DDInterfaceManager : NSObject

@property(nonatomic, assign) NSInteger environment;


@end

NS_ASSUME_NONNULL_END
