//
//  DDLBaseKitManager.h
//  AFNetworking
//
//  Created by wanggang on 2020/4/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@protocol DDLBaseKitManagerDelegate <NSObject>
@optional

/**
 掉线
 */
- (void)dd_offline;

/**
 扫描二维码结果出来

 @param result 二维码
 */
- (void)dd_scanResult:(NSString *)result success:(void(^)(id _Nullable data,NSString *msg))success fail:(void(^)(id _Nullable data,NSString *msg))fail;

@end
/**
 点都基本配置管理
 */
@interface DDLBaseKitManager : NSObject

@property (nonatomic,weak) id<DDLBaseKitManagerDelegate> delegate;

@property(nonatomic, assign) NSInteger environment;

+ (instancetype)shareBaseManager;

/**
 注册点都账号

 @param user 账号
 */
- (void)regirstDDBaseKit:(UserData *)user;

/**
 设置环境

 @param environment 0:正式环境 1:测试环境
 */
- (void)setEnvironment:(NSInteger)environment;
@end

NS_ASSUME_NONNULL_END
