//
//  SYContactsPickerController.h
//  SYContactsPicker
//
//  Created by reesun on 15/12/30.
//  Copyright © 2015年 SY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYContacter.h"
@class SYContactsPickerController;


@protocol SYContactsPickerControllerDelegate <NSObject>
@optional
/**
 联系人已选择 （多选时用这个）
 */
- (void)contactsPickerController:(SYContactsPickerController *)picker didFinishPickingContacts:(NSArray *)contacts;
/**
 已选择该联系人（单选时用这个）
 */
- (void)contactsPickerController:(SYContactsPickerController *)picker didSelectContacter:(SYContacter *)contacter;
/**
 联系人选择器已关闭
 */
- (void)contactsPickerControllerDidCancel:(SYContactsPickerController *)picker;

@end

@interface SYContactsPickerController : UIViewController

@property (nonatomic, weak) id<SYContactsPickerControllerDelegate>delegate;
/**
 允许多选
 */
@property (nonatomic, assign) BOOL allowMany;

@end
