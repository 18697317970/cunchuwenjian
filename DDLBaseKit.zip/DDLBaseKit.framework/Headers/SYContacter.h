//
//  SYContacter.h
//  SYContactsPicker
//
//  Created by reesun on 15/12/30.
//  Copyright © 2015年 SY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SYContacter : NSObject

@property (nonatomic) NSInteger section;
@property (nonatomic) NSInteger recordID;
@property (nonatomic) BOOL selected;
/**名称*/
@property (nonatomic, copy) NSString *name;
/**电话*/
@property (nonatomic, copy) NSString *phone;
/**邮箱*/
@property (nonatomic, copy) NSString *email;
/**获取名称*/
- (NSString *)getContacterName;

@end
