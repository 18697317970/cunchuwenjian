//
//  WGMineSetionBackLayout.h
//  DDLife
//
//  Created by wanggang on 2019/7/18.
//  Copyright © 2019年 赵越. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static NSString * const DDSetSectionBack = @"DDSetSectionBack";

@protocol DDSetSectionBackgroundLayoutDelegate<NSObject>

@required
-(UIEdgeInsets)cccollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section;
-(CGSize)cccollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout headerForSectionAtIndex:(NSInteger)section;
- (NSInteger)ccollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout backgroundColorForSection:(NSInteger)section;


@optional
-(CGSize)cccollectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout footerForSectionAtIndex:(NSInteger)section;

@end
/**
 设置setion整体背景
 */
@interface WGMineSetionBackLayout : UICollectionViewFlowLayout

@property (nonatomic, assign)id<DDSetSectionBackgroundLayoutDelegate> mydelegate;

@end

NS_ASSUME_NONNULL_END
