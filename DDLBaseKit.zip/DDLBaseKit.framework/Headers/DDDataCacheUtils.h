//
//  DDDataCacheUtils.h
//  DDLife
//
//  Created by wanggang on 2019/7/23.
//  Copyright © 2019年 赵越. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DDDataCacheUtils : NSObject

+ (DDDataCacheUtils *)sharedDDDataCacheUtils;

- (void)removeAll;
/**
 保存云门禁列表
 
 @param guard 门禁
 */
- (void)saveEntranceGuard:(NSArray *)guard;

/**
 获取云门禁列表
 
 @return 门禁
 */
- (NSArray *)getEntranceGuard;

/**
 保存用户信息
 
 @param userInfo 用户信息
 */
- (void)saveUserInfo:(UserData *)userInfo;

/**
 获取用户信息
 
 @return 用户信息
 */
- (UserData *)getUserInfo;
/**
 保存车牌号输入历史
 
 @param his 输入历史
 */
- (void)saveEnterCarNo:(NSArray *)his;

/**
 获取车牌号输入历史
 
 @return 用户信息
 */
- (NSArray *)getEnterCarNo;

/**
 清空车牌号输入历史
 */
- (void)removeEnterCarNo;

@end

NS_ASSUME_NONNULL_END
