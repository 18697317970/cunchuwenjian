//
//  NSDictionary+LogChinese.h
//  EffectiveDemo
//
//  Created by TomLong on 2019/8/16.
//  Copyright © 2019年 ZLJ. All rights reserved.
//
/**
 
 汉字在控制台输出显示
 */
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (LogChinese)

@end

NS_ASSUME_NONNULL_END
