//
//  ResponseCode.h
//  DDLife
//
//  Created by 赵越 on 2019/7/11.
//  Copyright © 2019 赵越. All rights reserved.
//

#ifndef ResponseCode_h
#define ResponseCode_h


//                      ------ 网络请求返回code ------

#define RSP_SUCCESS             @"1"                 /**< 网络请求成功 */



#endif /* ResponseCode_h */
