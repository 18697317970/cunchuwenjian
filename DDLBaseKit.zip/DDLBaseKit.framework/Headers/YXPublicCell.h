//
//  YXPublicCell.h
//  ZanXiaoQu
//
//  Created by 杨旭 on 2018/10/27.
//  Copyright © 2018年 DianDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LTLimitTextField.h"

NS_ASSUME_NONNULL_BEGIN

@interface YXPublicCell : UITableViewCell

@property (nonatomic ,strong) UILabel *titleLab;
@property (nonatomic ,strong) UILabel *contentLab;

/** 标题*/
@property (nonatomic, strong) NSString *title;
/** 内容*/
@property (nonatomic, strong) NSString *content;

/** 标题大小*/
@property (nonatomic ,assign) CGFloat font;
/** 标题颜色*/
@property (nonatomic ,strong) UIColor *titleColor;

@property (nonatomic, assign) CGFloat leftCons;

@property (nonatomic, assign) CGFloat rightCons;

@end


@interface YXPublicCell1 : UITableViewCell


/** 标题*/
@property (nonatomic, strong) NSString *title;

/** 子标题*/
@property (nonatomic, strong) NSString *subTitle;

/** 右边标题*/
@property (nonatomic, strong) NSString *rightTitle;


@property (nonatomic, assign) CGFloat rightCons;
@end





@interface YXPublicCell2 : UITableViewCell

@property (nonatomic ,copy) void(^editTextBlock)(NSString *text);


/** 标题*/
@property (nonatomic ,strong) UILabel *titleLab;
/** 输入框*/
@property (nonatomic ,strong) UITextField *contentTF;

@property (nonatomic, assign) CGFloat leftCons;

@end


@interface YXPublicCell3 : UITableViewCell

@property (nonatomic ,copy) void(^swtichOnOrOff)(BOOL status);


/** 标题*/
@property (nonatomic ,strong) UILabel *titleLab;
/** 右边切换按钮*/
@property (nonatomic ,strong) UISwitch *isSwitch;

/** 标题大小*/
@property (nonatomic ,assign) CGFloat font;
/** 标题颜色*/
@property (nonatomic ,strong) UIColor *titleColor;

@end


@interface YXPublicCell4 : UITableViewCell

@property (nonatomic ,copy) void(^editTextBlock)(NSString *text);

@property (nonatomic ,assign) NSInteger index;///<1:手机号2:收货人


/** 标题*/
@property (nonatomic ,strong) UILabel *titleLab;
/** 输入框*/
@property (nonatomic ,strong) LTLimitTextField *contentTF;
@property (nonatomic ,strong) UIButton *select;

/** 标题大小*/
@property (nonatomic ,assign) CGFloat font;
/** 标题颜色*/
@property (nonatomic ,strong) UIColor *titleColor;
/** 设置输入框文字大小*/
@property (nonatomic ,assign) CGFloat tfFont;

@end

@interface YXPublicCell5 : UITableViewCell

@property (nonatomic ,strong) UILabel *titleLab;
@property (nonatomic ,strong) UILabel *contentLab;

@end

/**
 输入框
 */
@interface YXPublicCell6 : UITableViewCell

@property (nonatomic ,copy) void(^editTextBlock)(NSString *text);

@property (nonatomic ,strong) NSString *placeholder;
@property (nonatomic ,strong) NSString *text;

@end

NS_ASSUME_NONNULL_END
