//
//  YXPublicBottmView.h
//  ZanXiaoQu
//
//  Created by 杨旭 on 2018/10/18.
//  Copyright © 2018年 DianDu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YXPublicBottmView : UIView
@property (nonatomic ,copy)void(^clickButtonBlock)(void);
@property (nonatomic ,strong) NSString *title;
@property (nonatomic ,assign) CGFloat font;
@property (nonatomic ,strong) UIColor *backgroundColor;
@end

NS_ASSUME_NONNULL_END
